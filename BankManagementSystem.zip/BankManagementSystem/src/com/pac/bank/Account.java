package com.pac.bank;

//Account.java
public abstract class Account {
 protected String accountNumber;
 protected String accountHolderName;
 protected double accountBalance;
 protected String accHolderAddress;
 protected String contactNumber;
 protected String type;

 public Account(String accountNumber, String accountHolderName, double accountBalance,
                String accHolderAddress, String contactNumber, String type) {
     this.accountNumber = accountNumber;
     this.accountHolderName = accountHolderName;
     this.accountBalance = accountBalance;
     this.accHolderAddress = accHolderAddress;
     this.contactNumber = contactNumber;
     this.type = type;
 }

 public abstract void withdraw(double amount);
 public abstract void calculateInterest();
 public abstract void displayAllDetails();

 public void deposit(double amount) {
     accountBalance += amount;
     System.out.printf("Deposited Rs. %.2f. New balance: Rs. %.2f%n", amount, accountBalance);
 }

 // Update details based on user selection
 public void updateDetails(int choice, String newValue) {
     switch (choice) {
         case 1:
             this.accountHolderName = newValue;
             System.out.println("✔ Account holder name updated successfully.");
             break;
         case 2:
             this.accHolderAddress = newValue;
             System.out.println("✔ Account address updated successfully.");
             break;
         case 3:
             this.contactNumber = newValue;
             System.out.println("✔ Account contact number updated successfully.");
             break;
         default:
             System.out.println("❌ Invalid update choice!");
     }
 }

 // Utility method for printing headers
 protected void printHeader(String title) {
     System.out.println("=".repeat(50));
     System.out.printf("%25s%n", title);
     System.out.println("=".repeat(50));
 }
}
