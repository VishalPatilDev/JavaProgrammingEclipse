package com.pac.bank;

//Bank.java
import java.util.ArrayList;
import java.util.List;

public class Bank {
 private List<Account> accounts;

 public Bank() {
     accounts = new ArrayList<>();
 }

 public void addAccount(Account account) {
     accounts.add(account);
     System.out.println("Account successfully added: " + account.accountNumber);
 }

 public Account findAccount(String accountNumber) {
     for (Account account : accounts) {
         if (account.accountNumber.equals(accountNumber)) {
             return account;
         }
     }
     return null;
 }

 public void deleteAccount(String accountNumber) {
     Account account = findAccount(accountNumber);
     if (account != null) {
         accounts.remove(account);
         System.out.println("Account " + accountNumber + " has been deleted.");
     } else {
         System.out.println("Account not found.");
     }
 }

 public void displayAllAccounts() {
     if (accounts.isEmpty()) {
         System.out.println("No accounts available in the bank.");
         return;
     }
     for (Account account : accounts) {
         account.displayAllDetails();
     }
 }

 public void calculateInterestForAll() {
     if (accounts.isEmpty()) {
         System.out.println("No accounts available to calculate interest.");
         return;
     }
     for (Account account : accounts) {
         account.calculateInterest();
     }
 }
}
