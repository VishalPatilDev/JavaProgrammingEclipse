package com.pac.bank;

//BankManagementSystem.java
import java.util.Scanner;

public class BankMS {
 static Bank bank = new Bank();
 static Scanner sc = new Scanner(System.in);

 public static void main(String[] args) {
     boolean exit = false;

     // Adding default accounts for demonstration
     bank.addAccount(new SavingsAccount("SAV001", "Alice", 15000, "123 Street", "1234567890"));
     bank.addAccount(new CurrentAccount("CUR001", "Bob", 5000, "456 Avenue", "9876543210"));
     bank.addAccount(new LoanAccount("LOAN001", "Charlie", 50000, "789 Boulevard", "5554443322"));
     bank.addAccount(new SalaryAccount("SAL001", "David", 20000, "321 Road", "1122334455"));

     while (!exit) {
         System.out.println("\n" + "=".repeat(50));
         System.out.printf("%25s%n", "BANK MANAGEMENT SYSTEM");
         System.out.println("=".repeat(50));
         System.out.println("1. Counter Activities");
         System.out.println("2. Account Lifecycle");
         System.out.println("3. Interest Calculation");
         System.out.println("4. Exit");
         System.out.println("=".repeat(50));
         System.out.print("Enter your choice: ");
         int choice = sc.nextInt();

         switch (choice) {
             case 1:
                 counterActivities();
                 break;
             case 2:
                 bank.displayAllAccounts();
                 break;
             case 3:
                 bank.calculateInterestForAll();
                 break;
             case 4:
                 exit = true;
                 System.out.println("Exiting... Thank you for using Bank Management System!");
                 break;
             default:
                 System.out.println("❌ Invalid choice! Please enter a number between 1 and 4.");
         }
     }
 }

 static void counterActivities() {
     System.out.println("\n" + "-".repeat(50));
     System.out.println("             COUNTER ACTIVITIES");
     System.out.println("-".repeat(50));

     System.out.print("Enter Account Number: ");
     String accNum = sc.next();
     Account acc = bank.findAccount(accNum);
     if (acc == null) {
         System.out.println("❌ Account not found!");
         return;
     }

     System.out.println("1. Withdraw  2. Deposit  3. Update  4. Delete");
     System.out.print("Enter your choice: ");
     int action = sc.nextInt();

     switch (action) {
         case 1:
             System.out.print("Enter Amount to Withdraw: ");
             double withdrawAmount = sc.nextDouble();
             acc.withdraw(withdrawAmount);
             break;
         case 2:
             System.out.print("Enter Amount to Deposit: ");
             double depositAmount = sc.nextDouble();
             acc.deposit(depositAmount);
             break;
         case 3:
             System.out.println("What would you like to update?");
             System.out.println("1. Name  2. Address  3. Contact Number");
             System.out.print("Enter your choice: ");
             int updateChoice = sc.nextInt();
             sc.nextLine(); // Clear the buffer
             System.out.print("Enter new value: ");
             String newValue = sc.nextLine();
             acc.updateDetails(updateChoice, newValue);
             break;
         case 4:
             bank.deleteAccount(accNum);
             break;
         default:
             System.out.println("❌ Invalid action!");
     }
 }
}
