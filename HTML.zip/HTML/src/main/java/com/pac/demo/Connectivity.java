package com.pac.demo;


//This is the Data Access Layer component
public interface Connectivity {
	public boolean isValid(Card ref);
}
